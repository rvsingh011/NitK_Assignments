To run the application do the following:

In Windows
----------

Run the run.bat file

In other OS
-----------

java -cp jars/simjava2.jar;jars/gridsim.jar;jars/iText-2.1.5.jar;classes;. cloudsim.ext.gui.GuiMain